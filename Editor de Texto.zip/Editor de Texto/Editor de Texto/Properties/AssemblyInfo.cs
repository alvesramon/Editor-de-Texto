﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Informações gerais sobre um assembly são controladas através do seguinte 
// conjunto de atributos. Altere o valor destes atributos para modificar a informação
// associada a um assembly.
[assembly: AssemblyTitle("Editor de Texto")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("Editor de Texto")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2012")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Definir ComVisible como false torna os tipos neste assembly não visíveis 
// para componentes COM.  Se você precisa acessar um tipo na forma de assembly em 
// COM, defina o atributo ComVisible como true nesse tipo.
[assembly: ComVisible(false)]

// O GUID a seguir é para o ID da typelib se este projeto for exposto para COM
[assembly: Guid("e854d99e-82ef-404e-8f60-93b1205c499f")]

// Informações de Versão para um assembly consistem nos quatro valores a seguir:
//
//      Versão Principal
//      Versão Secundária 
//      Número da Versão
//      Revisão
//
// É possível especificar todos os valores ou usar o padrão de números da Versão e Revisão 
// utilizando o '*' como mostrado abaixo:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
